package ru.job4j.io;


public class Test {
    public static void main(String[] args) {
        System.out.println("Hello");
    }
}
