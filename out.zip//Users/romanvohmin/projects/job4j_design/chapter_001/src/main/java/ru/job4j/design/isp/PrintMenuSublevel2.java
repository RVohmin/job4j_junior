package ru.job4j.design.isp;

/**
 * @author RVohmin
 * @since 19.03.2020
 */
public interface PrintMenuSublevel2 {
    String printSubLevel2(MenuSublevel menuSublevel);
}
